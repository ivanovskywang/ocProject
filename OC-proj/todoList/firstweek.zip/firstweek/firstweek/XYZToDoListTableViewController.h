//
//  XYZToDoListTableViewController.h
//  firstweek
//
//  Created by Arlongwang on 2018/5/24.
//  Copyright © 2018年 Arlongwang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XYZAddToDoItemViewController.h"

@interface XYZToDoListTableViewController : UITableViewController
-(IBAction)unwindToList:(UIStoryboardSegue *)segue;

@end
