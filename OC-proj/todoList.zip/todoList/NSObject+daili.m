//
//  NSObject+daili.m
//  firstweek
//
//  Created by Arlongwang on 2018/5/22.
//  Copyright © 2018年 Arlongwang. All rights reserved.
//

#import "NSObject+daili.h"

@implementation NSObject (daili)

@end
